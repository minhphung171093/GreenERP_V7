from . import test_tax
from . import test_search

fast_suite = [
	test_tax,
	test_search,
]
