.. _changelog:

Changelog
=========

`7.0`
-----

- Modules may now include an ``i18n_extra`` directory that will be treated like the
  default ``i18n`` directory. This is typically useful for manual translation files
  that are not managed by Launchpad's translation system. An example is l10n modules
  that depend on ``l10n_multilang``.


