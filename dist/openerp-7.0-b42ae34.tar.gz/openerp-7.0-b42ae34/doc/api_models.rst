
ORM and models
--------------

.. automodule:: openerp.osv.orm
   :members:
   :undoc-members:
